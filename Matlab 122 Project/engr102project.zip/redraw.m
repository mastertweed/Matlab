function redraw
% function to redraw objects on a screen
% used for animation
drawnow
